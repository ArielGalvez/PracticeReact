export async function GetTeam(id) {
    const team = {
        nameTeamValue: 'Team Test One',
        members: ["1", "3"]
    }
    return team;
}